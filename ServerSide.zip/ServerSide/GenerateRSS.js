const { writeFile } = require('fs');
const RSSCombiner = require('rss-combiner');
const cron = require('node-cron');

var Plexusfeed = {
  title: 'RSS feed',
  size: 50,
  feeds: [
    //'http://feeds.bbci.co.uk/news/technology/rss.xml',
    //'https://www.theguardian.com/uk/technology/rss',
    //'https://www.reddit.com/r/news/.rss',
    //'https://www.lemonde.fr/international/rss_full.xml',
    //'http://www.reddit.com/.rss',
    //'http://lorem-rss.herokuapp.com/feed?length=42',
    'https://www.bretagne.ars.sante.fr/rss.xml'
  ],
  pubDate: new Date()
};

var Allfeed = {
  title: 'All Feed',
  size: 300,
  feeds: [
    'http://feeds.bbci.co.uk/news/technology/rss.xml',
    'https://www.theguardian.com/uk/technology/rss',
    'https://www.lemonde.fr/international/rss_full.xml',
    'https://www.reddit.com/r/news/.rss',
    'https://www.bretagne.ars.sante.fr/rss.xml'
  ],
  pubDate: new Date()
};

cron.schedule('* * * * *', function() {
  const newdate = new Date()
  console.log(`Updating RSS feeds [${newdate}]`);

  // Node callback usage
  RSSCombiner(Allfeed, function (err, combinedFeed) {
    if (err) {
      console.error(err);
    } else {
      var xml = combinedFeed.xml();
      writeFile('ServerSide/feed/AllRSS.xml', xml, (err) => {
        if (err) throw err;
        console.log('└ "AllRSS.xml" has been saved!');
      });
    }
  });

  // Node callback usage
  RSSCombiner(Plexusfeed, function (err, combinedFeed) {
    if (err) {
      console.error(err);
    } else {
      var xml = combinedFeed.xml();
      writeFile('ServerSide/feed/ARS Bretagne.xml', xml, (err) => {
        if (err) throw err;
        console.log('└ "ARS Bretagne.xml" has been saved!');
      });
    }
  });

});